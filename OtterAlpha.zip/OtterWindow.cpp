#include "Otter.h"

void OtterWindow::OtterWin::CreateWindowNew(
    std::wstring NAME, int A, std::wstring Lname,
    int X, int Y, int W, int H,
    HWND AW, HMENU men, LPVOID OID)
{
    this->CLASS_NAME = NAME;
    this->wc.lpfnWndProc = WindowProc;
    this->wc.lpszClassName = this->CLASS_NAME.c_str();
    this->wc.hInstance = this->hInstance;
    // 注意：hbrBackground在SetLayeredMode中设置

    RegisterClass(&this->wc);

    // 根据模式设置扩展样式
    DWORD exStyle = A;
    if (isLayeredWindow) {
        exStyle |= WS_EX_LAYERED;
    }

    hwndr = CreateWindowExW(
        exStyle,
        CLASS_NAME.c_str(),
        Lname.c_str(),
        WS_OVERLAPPEDWINDOW,
        X, Y, W, H,
        AW, men, hInstance, this
    );
}

void OtterWindow::OtterWin::ShowWindowR() {

    // 设置窗口样式避免闪烁
    //SetWindowLong(hwndr, GWL_STYLE, GetWindowLong(hwndr, GWL_STYLE) & ~WS_CAPTION);
   // SetWindowPos(hwndr, NULL, 0, 0, 0, 0,
       // SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);

    if (isLayeredWindow) {
        // 分层窗口特殊初始化
        RECT rect;
        GetClientRect(hwndr, &rect);

        HDC hdc = GetDC(hwndr);

        // 创建临时绘图表面
        {
            OtterPaintbrush brush(hwndr, true);
            brush.Update();
        }

        HDC memDC = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, rect.right, rect.bottom);
        SelectObject(memDC, hBitmap);

        Gdiplus::Graphics graphics(memDC);
        graphics.Clear(Gdiplus::Color(0, 0, 0, 0)); // 透明背景

        BLENDFUNCTION blend = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
        POINT ptPos = { 0, 0 };
        SIZE sizeWnd = { rect.right, rect.bottom };
        UpdateLayeredWindow(hwndr, hdc, NULL, &sizeWnd, memDC, &ptPos, 0, &blend, ULW_ALPHA);

        DeleteObject(hBitmap);
        DeleteDC(memDC);
        ReleaseDC(hwndr, hdc);
    }

    // 显示窗口（两种模式通用）
    ::ShowWindow(hwndr, nCmdShow);
    UpdateWindow(hwndr);
}